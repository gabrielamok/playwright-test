from playwright.async_api import Page

class DemoPage:
    def __init__(self, page: Page):
        self.page = page
        self.first_name_input = "input[name='first_name']"
        self.last_name_input = "input[name='last_name']"
        self.whatsapp_input = "input[name='whatsapp']"
        self.business_name_input = "input[name='business_name']"
        self.result_input = "input#number"
        self.submit_button = "#demo"
        self.confirmation_message = ".confirmation-message-class"  # Update this as needed

    async def navigate_to_demo_page(self, url: str):
        await self.page.goto(url)

    async def fill_form(self, first_name, last_name, whatsapp, business_name, result):
        await self.page.fill(self.first_name_input, first_name)
        await self.page.fill(self.last_name_input, last_name)
        await self.page.fill(self.whatsapp_input, whatsapp)
        await self.page.fill(self.business_name_input, business_name)
        await self.page.fill(self.result_input, result)

    async def submit_form(self):
        await self.page.click(self.submit_button)

    async def get_confirmation_message(self):
        try:
            await self.page.wait_for_selector(self.confirmation_message, timeout=5000)
            return await self.page.text_content(self.confirmation_message)
        except Exception:
            return "No confirmation message found or submission failed."
