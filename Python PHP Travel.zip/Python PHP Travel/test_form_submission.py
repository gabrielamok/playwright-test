import asyncio
from playwright.async_api import async_playwright
from datetime import datetime
from pages.demo_page import DemoPage

async def test_form_submission():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        # Instantiate the DemoPage
        demo_page = DemoPage(page)

        # Test data
        first_name = "Gabriel"
        last_name = "Alves"
        whatsapp = "11970306660"
        business_name = "Beating bad Guys"
        result = "19"

        # Navigate and perform actions
        await demo_page.navigate_to_demo_page("https://phptravels.com/demo/")
        await demo_page.fill_form(first_name, last_name, whatsapp, business_name, result)
        await demo_page.submit_form()
        confirmation_message = await demo_page.get_confirmation_message()

        # Save the result
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        result_text = (
            f"Timestamp: {timestamp}\n"
            f"First Name: {first_name}\n"
            f"Last Name: {last_name}\n"
            f"WhatsApp Number: {whatsapp}\n"
            f"Business Name: {business_name}\n"
            f"Result Number: {result}\n"
            f"Submission Status: {confirmation_message}\n"
        )

        with open("form_submission_result.txt", "w", encoding="utf-8") as file:
            file.write(result_text)

        # Close the browser
        await browser.close()

# Run the test
asyncio.run(test_form_submission())
