import asyncio
from datetime import datetime
from playwright.async_api import async_playwright

async def fill_form_and_submit():
    # Launch the browser
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        # Navigate to the website
        await page.goto("https://phptravels.com/demo/")

        # Fill in the form fields
        first_name = "Gabriel"
        last_name = "Alves"
        whatsapp_number = "11970306660"
        business_name = "Beating bad Guys"
        result_number = "19"
        
        await page.fill("input[name='first_name']", first_name)
        await page.fill("input[name='last_name']", last_name)  # Assuming there's a separate field for last name
        await page.fill("input[name='whatsapp']", whatsapp_number)
        await page.fill("input[name='business_name']", business_name)
        await page.fill("input#number", result_number)

        # Click the submit button
        await page.click("#demo")

        # Wait for a confirmation message or response (adjust selector as needed)
        try:
            confirmation_selector = ".confirmation-message-class"  # Replace with actual selector
            await page.wait_for_selector(confirmation_selector, timeout=5000)
            confirmation_message = await page.text_content(confirmation_selector)
        except Exception:
            confirmation_message = "No confirmation message found or submission failed."

        # Save the result
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        result_text = (
            f"Timestamp: {timestamp}\n"
            f"First Name: {first_name}\n"
            f"Last Name: {last_name}\n"
            f"WhatsApp Number: {whatsapp_number}\n"
            f"Business Name: {business_name}\n"
            f"Result Number: {result_number}\n"
            f"Submission Status: {confirmation_message}\n"
        )

        # Write the result to a text file
        with open("form_submission_result.txt", "w", encoding="utf-8") as file:
            file.write(result_text)

        # Close the browser
        await browser.close()

# Run the script
asyncio.run(fill_form_and_submit())
