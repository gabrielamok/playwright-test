# Playwright Test with POM Model

This project demonstrates how to automate a form submission test using Playwright and the Page Object Model (POM) design pattern.

## Features
- Uses Playwright for browser automation.
- Implements the POM model for better modularity and reusability.
- Saves test results to a text file.

## File Structure
playwright_test/ ├── pages/ │ ├── demo_page.py # Contains the logic and elements for the demo page. ├── tests/ │ ├── test_form_submission.py # Contains test logic.