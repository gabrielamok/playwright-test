import os
import yaml
from playwright.sync_api import sync_playwright

def load_users_from_yaml(file_path):
    """Loads user data from a YAML file."""
    try:
        with open(file_path, "r") as file:
            users = yaml.safe_load(file)
            if not users:
                raise ValueError("No users found in the YAML file.")
            return users
    except FileNotFoundError:
        print(f"YAML file not found: {file_path}")
        raise
    except yaml.YAMLError as e:
        print(f"Error reading YAML file: {e}")
        raise

def log_result(message):
    """Logs the result to a text file."""
    with open("account_creation_results.txt", "a") as log_file:
        log_file.write(message + "\n")

def create_account(user):
    """Automates account creation using Playwright."""
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        page = browser.new_page()
        try:
            # Navigate to the Magento registration page
            page.goto("https://magento.softwaretestingboard.com/customer/account/create/")

            # Fill out the registration form
            page.fill("input#firstname", user.get("firstname", ""))
            page.fill("input#lastname", user.get("lastname", ""))
            page.fill("input#email_address", user.get("email", ""))
            page.fill("input#password", user.get("password", ""))
            page.fill("input#password-confirmation", user.get("password", ""))

            # Check the "Sign Up for Newsletter" checkbox if available (optional)
            try:
                page.check("input[name='is_subscribed']")
            except Exception:
                print("Newsletter subscription checkbox not found; continuing...")

            # Click the "Create an Account" button
            page.click("button[title='Create an Account']")

            # Wait for the success message or next page indicator
            page.wait_for_selector("text='Thank you for registering with Main Website Store.'", timeout=10000)
            result_message = f"Account creation successful for: {user['firstname']} {user['lastname']}"
            print(result_message)
            log_result(result_message)
        except Exception as e:
            error_message = f"Error creating account for {user.get('firstname', 'Unknown')}: {e}"
            print(error_message)
            log_result(error_message)
        finally:
            page.close()
            browser.close()

def main():
    yaml_file = "C:/Users/Gabriel/Desktop/playwright study/Python for PHP Travel/yml/user.yml"
    
    # Load users
    try:
        users = load_users_from_yaml(yaml_file)
        for user in users:
            create_account(user)
    except Exception as e:
        print(f"An error occurred: {e}")
        log_result(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
