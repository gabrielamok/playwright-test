from playwright.sync_api import Page

class AccountCreationPage:
    def __init__(self, page: Page):
        self.page = page
        self.first_name = page.locator("#firstname")
        self.last_name = page.locator("#lastname")
        self.email = page.locator("#email_address")
        self.password = page.locator("#password")
        self.confirm_password = page.locator("#password-confirmation")
        self.submit_button = page.locator("button[title='Create an Account']")

    def navigate(self, url: str):
        self.page.goto(url)

    def fill_form(self, first_name: str, last_name: str, email: str, password: str):
        self.first_name.fill(first_name)
        self.last_name.fill(last_name)
        self.email.fill(email)
        self.password.fill(password)
        self.confirm_password.fill(password)

    def submit_form(self):
        self.submit_button.click()
